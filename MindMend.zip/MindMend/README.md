# AI Mental Health Chatbot

A compassionate AI-powered mental health support chatbot that uses sentiment analysis to provide empathetic responses and daily positive quotes.

## Features

- **Sentiment Analysis**: Uses Hugging Face's DistilBERT model to detect user mood from text input
- **Empathetic Responses**: Provides supportive, tailored replies based on detected sentiment
- **Daily Positive Quotes**: Fetches inspiring quotes from the ZenQuotes API
- **Chat Interface**: Clean, calming web interface with chat-style messaging
- **Conversation History**: Saves all conversations to a text file for record-keeping

## Setup Instructions

### Prerequisites

- Python 3.11 or higher
- pip (Python package manager)

### Installation

1. Install the required dependencies:
```bash
pip install -r requirements.txt
```

2. Run the Flask application:
```bash
python app.py
```

3. Open your browser and navigate to:
```
http://localhost:5000
```

## Usage

1. The app displays a daily positive quote at the top
2. Type your thoughts or feelings in the input box
3. Press "Send" or hit Enter to submit
4. The chatbot analyzes your sentiment and responds empathetically
5. All conversations are saved to `conversation_history.txt`

## Dependencies

- **Flask**: Web framework for the application
- **Transformers**: Hugging Face library for sentiment analysis
- **Torch**: PyTorch backend for the ML model
- **Requests**: For fetching quotes from ZenQuotes API

## How It Works

1. User enters text describing their feelings
2. The app uses a pre-trained DistilBERT sentiment analysis model to detect mood (positive/negative)
3. Based on the detected sentiment, the bot selects an appropriate empathetic response
4. The conversation is saved with timestamp and sentiment data
5. A new daily quote is displayed on each page load

## Important Note

This chatbot is designed for general emotional support and positive interaction. It is **not a substitute for professional mental health care**. If you're experiencing a mental health crisis, please contact:

- National Suicide Prevention Lifeline: 988
- Crisis Text Line: Text HOME to 741741
- Or contact a mental health professional

## File Structure

```
.
├── app.py                      # Main Flask application
├── requirements.txt            # Python dependencies
├── README.md                   # This file
├── conversation_history.txt    # Saved conversations (auto-generated)
├── templates/
│   └── index.html             # Chat interface template
└── static/
    └── style.css              # Styling for the web app
```

## License

This project is provided as-is for educational and supportive purposes.

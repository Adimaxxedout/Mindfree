from flask import Flask, render_template, request, jsonify
from transformers import pipeline
import requests
from datetime import datetime
import os

app = Flask(__name__)

sentiment_analyzer = pipeline("sentiment-analysis", model="distilbert-base-uncased-finetuned-sst-2-english")

CONVERSATION_FILE = "conversation_history.txt"

empathetic_responses = {
    "POSITIVE": [
        "I'm so glad to hear you're feeling good! That's wonderful. Keep embracing those positive vibes!",
        "It's great to see you in such a positive mindset! You deserve all this happiness.",
        "Your positive energy is contagious! Keep celebrating the good moments in life.",
        "That's amazing! It's beautiful when things feel right. Enjoy this feeling!",
    ],
    "NEGATIVE": [
        "I hear you, and I want you to know that it's okay to feel this way. Your feelings are valid.",
        "I'm here for you. It sounds like you're going through a tough time. Remember, this too shall pass.",
        "I understand this is difficult. Please be gentle with yourself during this challenging time.",
        "Your feelings matter, and it's brave of you to express them. You're not alone in this.",
        "I'm sorry you're experiencing this. Remember that difficult emotions are temporary, and brighter days are ahead.",
    ]
}

def get_daily_quote():
    try:
        response = requests.get("https://zenquotes.io/api/today", timeout=5)
        if response.status_code == 200:
            data = response.json()
            if data and len(data) > 0:
                return f"{data[0]['q']} - {data[0]['a']}"
    except:
        pass
    return "Every day may not be good, but there is something good in every day."

def analyze_sentiment(text):
    result = sentiment_analyzer(text[:512])[0]
    return result['label'], result['score']

def get_empathetic_response(sentiment):
    import random
    responses = empathetic_responses.get(sentiment, empathetic_responses["POSITIVE"])
    return random.choice(responses)

def save_conversation(user_message, bot_response, sentiment):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(CONVERSATION_FILE, "a", encoding="utf-8") as f:
        f.write(f"\n{'='*60}\n")
        f.write(f"Time: {timestamp}\n")
        f.write(f"User: {user_message}\n")
        f.write(f"Detected Mood: {sentiment}\n")
        f.write(f"Bot: {bot_response}\n")

@app.route('/')
def home():
    quote = get_daily_quote()
    return render_template('index.html', daily_quote=quote)

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get('message', '')
    
    if not user_message.strip():
        return jsonify({'error': 'Please enter a message'}), 400
    
    sentiment, confidence = analyze_sentiment(user_message)
    
    response = get_empathetic_response(sentiment)
    
    save_conversation(user_message, response, sentiment)
    
    return jsonify({
        'response': response,
        'sentiment': sentiment.lower(),
        'confidence': round(confidence * 100, 1)
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
